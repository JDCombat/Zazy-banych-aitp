Aby zaimportować bazę danych trzeba zrobić to w terminalu
Przejść do folderu C:/xampp/mysql/bin
Uruchomić program: mysql.exe -u root -p
Stworzyć bazę danych: CREATE DATABASE [nazwa];
Użyć ją: use [nazwa]
Zaimportować: source [ścieżka do pliku];

Tyle :3